Hello, this is our rough draft of our pcb schematic and layout.
After finishing this, I believe that having the TM4C chip on the board was a mistake due to the number of analog components and pins used.

The spice model of the analog components is included in filters.asc

Thanks